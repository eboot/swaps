#!/usr/bin/env python3

from swap.providers.xinfin.wallet import (
    Wallet, DEFAULT_PATH
)
from swap.providers.xinfin.transaction import NormalTransaction
from swap.providers.xinfin.signature import NormalSignature
from swap.providers.xinfin.solver import NormalSolver
from swap.providers.xinfin.rpc import get_xrc20_decimals
from swap.providers.xinfin.utils import submit_transaction_raw

import json

# Choose network mainnet, apothem or testnet
NETWORK: str = "apothem"
# Enable XinFin XRC20
XRC20: bool = True
# XinFin sender wallet mnemonic
SENDER_MNEMONIC: str = "unfair divorce remind addict add roof park clown build renew illness fault"
# XinFin XRC20 token address
TOKEN_ADDRESS: str = "xdcd66dA17A97a91445A2B89805e9fa4B0ff649BF49"
# XinFin recipient address and amount
RECIPIENT: dict = {
    "xdcf8D43806260CFc6cC79fB408BA1897054667F81C": 25 * (10 ** get_xrc20_decimals(token_address=TOKEN_ADDRESS, network=NETWORK))
}

print("=" * 10, "Sender XinFin Account")

# Initialize XinFin sender wallet
sender_wallet: Wallet = Wallet(network=NETWORK)
# Get XinFin sender wallet from mnemonic
sender_wallet.from_mnemonic(mnemonic=SENDER_MNEMONIC)
# Drive XinFin sender wallet from path
sender_wallet.from_path(path=DEFAULT_PATH)

# Print some XinFin sender wallet info's
print("Root XPrivate Key:", sender_wallet.root_xprivate_key())
print("Root XPublic Key:", sender_wallet.root_xpublic_key())
print("Private Key:", sender_wallet.private_key())
print("Public Key:", sender_wallet.public_key())
print("Path:", sender_wallet.path())
print("Address:", sender_wallet.address())
print("Balance:", sender_wallet.balance(unit="XDC"), "XDC")
print("XRC20 Balance:", sender_wallet.xrc20_balance(token_address=TOKEN_ADDRESS))

print("=" * 10, "Unsigned XRC20 Normal Transaction")

# Initialize XRC20 normal transaction
unsigned_normal_transaction: NormalTransaction = NormalTransaction(network=NETWORK, xrc20=XRC20)
# Build XRC20 normal transaction
unsigned_normal_transaction.build_transaction(
    address=sender_wallet.address(), recipient=RECIPIENT, token_address=TOKEN_ADDRESS
)

print("Unsigned XRC20 Normal Transaction Fee:", unsigned_normal_transaction.fee())
print("Unsigned XRC20 Normal Transaction Hash:", unsigned_normal_transaction.hash())
print("Unsigned XRC20 Normal Transaction Raw:", unsigned_normal_transaction.raw())
# print("Unsigned XRC20 Normal Transaction Json:", json.dumps(unsigned_normal_transaction.json(), indent=4))
print("Unsigned XRC20 Normal Transaction Signature:", json.dumps(unsigned_normal_transaction.signature(), indent=4))
print("Unsigned XRC20 Normal Transaction Type:", unsigned_normal_transaction.type())

unsigned_normal_transaction_raw: str = unsigned_normal_transaction.transaction_raw()
print("Unsigned XRC20 Normal Transaction Raw:", unsigned_normal_transaction_raw)

print("=" * 10, "Signed XRC20 Normal Transaction")

# Initialize normal solver
normal_solver: NormalSolver = NormalSolver(
    xprivate_key=sender_wallet.root_xprivate_key(), 
    path=sender_wallet.path()
)

# Sing unsigned XRC20 normal transaction
signed_normal_transaction: NormalTransaction = unsigned_normal_transaction.sign(solver=normal_solver)

print("Signed XRC20 Normal Transaction Fee:", signed_normal_transaction.fee())
print("Signed XRC20 Normal Transaction Hash:", signed_normal_transaction.hash())
print("Signed XRC20 Normal Transaction Main Raw:", signed_normal_transaction.raw())
# print("Signed XRC20 Normal Transaction Json:", json.dumps(signed_normal_transaction.json(), indent=4))
print("Signed XRC20 Normal Transaction Signature:", json.dumps(signed_normal_transaction.signature(), indent=4))
print("Signed XRC20 Normal Transaction Type:", signed_normal_transaction.type())

signed_normal_transaction_raw: str = signed_normal_transaction.transaction_raw()
print("Signed XRC20 Normal Transaction Raw:", signed_normal_transaction_raw)

print("=" * 10, "XRC20 Normal Signature")

# Initialize XRC20 normal signature
normal_signature: NormalSignature = NormalSignature(network=NETWORK, xrc20=XRC20)
# Sign unsigned XRC20 normal transaction raw
normal_signature.sign(
    transaction_raw=unsigned_normal_transaction_raw,
    solver=normal_solver
)

print("XRC20 Normal Signature Fee:", normal_signature.fee())
print("XRC20 Normal Signature Hash:", normal_signature.hash())
print("XRC20 Normal Signature Raw:", normal_signature.raw())
# print("XRC20 Normal Signature Json:", json.dumps(normal_signature.json(), indent=4))
print("XRC20 Normal Signature Signature:", json.dumps(normal_signature.signature(), indent=4))
print("XRC20 Normal Signature Type:", normal_signature.type())

signed_normal_signature_transaction_raw: str = normal_signature.transaction_raw()
print("XRC20 Normal Signature Transaction Raw:", signed_normal_signature_transaction_raw)

# Check both signed normal transaction raws are equal
assert signed_normal_transaction_raw == signed_normal_signature_transaction_raw

# Submit XRC20 normal transaction raw
# print("\nSubmitted XRC20 Normal Transaction:", json.dumps(submit_transaction_raw(
#     transaction_raw=signed_normal_transaction_raw  # Or signed_normal_signature_transaction_raw
# ), indent=4))
