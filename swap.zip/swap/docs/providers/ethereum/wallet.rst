:orphan:

Wallet
======
The implementation of Hierarchical Deterministic (HD) wallets generator for Ethereum blockchain.

.. automodule:: swap.providers.ethereum.wallet

.. autoclass:: Wallet
   :members:
