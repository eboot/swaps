:orphan:

Wallet
======
The implementation of Hierarchical Deterministic (HD) wallets generator for Vapor blockchain.

.. automodule:: swap.providers.vapor.wallet

.. autoclass:: Wallet
   :members:
