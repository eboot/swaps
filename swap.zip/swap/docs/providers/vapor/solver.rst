:orphan:

Solver
======
Vapor solver.

.. automodule:: swap.providers.vapor.solver

NormalSolver
------------
.. autoclass:: NormalSolver
   :members:

FundSolver
----------
.. autoclass:: FundSolver
   :members:

WithdrawSolver
--------------
.. autoclass:: WithdrawSolver
   :members:

RefundSolver
------------
.. autoclass:: RefundSolver
   :members:
