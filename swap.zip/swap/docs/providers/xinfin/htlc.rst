:orphan:

Hash Time Lock Contract (HTLC)
==============================
XinFin Hash Time Lock Contract (HTLC).

.. automodule:: swap.providers.xinfin.htlc

.. autoclass:: HTLC
   :members:
