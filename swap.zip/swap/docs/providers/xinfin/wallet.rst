:orphan:

Wallet
======
The implementation of Hierarchical Deterministic (HD) wallets generator for XinFin blockchain.

.. automodule:: swap.providers.xinfin.wallet

.. autoclass:: Wallet
   :members:
