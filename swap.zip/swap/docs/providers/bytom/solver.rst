:orphan:

Solver
======
Bytom solver.

.. automodule:: swap.providers.bytom.solver

NormalSolver
------------
.. autoclass:: NormalSolver
   :members:

FundSolver
----------
.. autoclass:: FundSolver
   :members:

WithdrawSolver
--------------
.. autoclass:: WithdrawSolver
   :members:

RefundSolver
------------
.. autoclass:: RefundSolver
   :members:
