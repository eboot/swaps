:orphan:

Wallet
======
The implementation of Hierarchical Deterministic (HD) wallets generator for Bitcoin blockchain.

.. automodule:: swap.providers.bitcoin.wallet

.. autoclass:: Wallet
   :members:
