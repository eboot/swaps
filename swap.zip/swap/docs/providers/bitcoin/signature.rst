:orphan:

Signature
=========
Bitcoin signature.

.. automodule:: swap.providers.bitcoin.signature

.. autoclass:: Signature
   :members:

NormalSignature
---------------
.. autoclass:: NormalSignature
   :members:

FundSignature
-------------
.. autoclass:: FundSignature
   :members:

WithdrawSignature
-----------------
.. autoclass:: WithdrawSignature
   :members:

RefundSignature
---------------
.. autoclass:: RefundSignature
   :members:
