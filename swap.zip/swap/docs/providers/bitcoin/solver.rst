:orphan:

Solver
======
Bitcoin solver.

.. automodule:: swap.providers.bitcoin.solver

NormalSolver
------------
.. autoclass:: NormalSolver
   :members:

FundSolver
----------
.. autoclass:: FundSolver
   :members:

WithdrawSolver
--------------
.. autoclass:: WithdrawSolver
   :members:

RefundSolver
------------
.. autoclass:: RefundSolver
   :members:
